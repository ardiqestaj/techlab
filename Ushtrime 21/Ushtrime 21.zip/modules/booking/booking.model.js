// TODO

// CREATE BOKKING MODULE, INCLUDIN MODEL CONTROLLER AND ROUTES
//     user qe ka bo booking
//     tour qe e ka bo book
//     guests, per sa vet e ka rezervu
//     data, data e rezervimit
//     data e krijimit
//     data e perditesimit

// DONT FOREGT TO FINNISH THOSE IN USER MODULE:
//     getMe
//     updateMe - dont allow to update role
