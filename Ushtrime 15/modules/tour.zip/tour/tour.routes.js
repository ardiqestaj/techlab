import express from "express";
import { createTour } from "./tour.controller.js";

const router = express();

router.post("/", createTour);

export default router;
